__all__ = ["Spectrum"]

import numpy as _np

class Spectrum(object):
    """Represents spectrum in memory."""

    def __init__(self, filename="default.txt"):
        self.filename = filename
        self.lamb = None
        self.flux = None

    def load(self):
        """Loads spectrum."""
        X = _np.loadtxt(self.filename)
        self.lamb = X[:, 0]
        self.flux = X[:, 1]

