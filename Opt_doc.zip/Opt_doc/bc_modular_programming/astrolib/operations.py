__all__ = ["Cutter", "ToMagnitude"]

import numpy as np
from spectrum import *

class Cutter(object):
    """Cuts spectrum to region of interest."""

    def __init__(self, left, right):
        self.left = left
        self.right = right

    def apply(self, input):
        idx_cut_left = np.argmin(np.abs(input.lamb-self.left))
        idx_cut_right = np.argmin(np.abs(input.lamb-self.right))
        # cuts lambdas and fluxes
        output = Spectrum()
        output.lamb = input.lamb[idx_cut_left:idx_cut_right+1]
        output.flux = input.flux[idx_cut_left:idx_cut_right+1]
        return output

class ToMagnitude(object):
    """Converts flux to magnitude."""

    def __init__(self, offset):
        self.offset = offset

    def apply(self, input):
        output = Spectrum()
        output.lamb = np.copy(input.lamb) # lambda vector is copied
        output.flux = -2.5 * np.log10(input.flux) + self.offset
        return output
