#!/usr/bin/python
#
# 3rd stage: converts flux to magnitude

import matplotlib.pyplot as plt
from astrolib import *

FILENAME = 'exemplo_espectro.txt'
LAMBDA_CUT_LEFT = 5000
LAMBDA_CUT_RIGHT = 9000
MAGNITUDE_OFFSET = -48.60

sp = Spectrum(FILENAME)
sp.load()


cutter = Cutter(LAMBDA_CUT_LEFT, LAMBDA_CUT_RIGHT)
to_mag = ToMagnitude(MAGNITUDE_OFFSET)

sequence = [to_mag, cutter, Cutter(6000, 7000)]


spectra = []
spectra.append(sp)

input = sp
for operation in sequence:
    output = operation.apply(input)
    spectra.append(output)
    input = output


# Visualizes the results
num_subplots = len(spectra)
for i in range(num_subplots):
    spectrum = spectra[i]
    plt.subplot(num_subplots, 1, i+1)
    plt.plot(spectrum.lamb, spectrum.flux)

plt.show()

