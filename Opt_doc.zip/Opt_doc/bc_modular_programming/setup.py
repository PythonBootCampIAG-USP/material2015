#!/usr/bin/env python
# -*- coding:utf-8 -*-

""" Installation of astrolib """

try:
    from setuptools import setup, find_packages
except ImportError:
    from distutils.core import setup, find_packages


def rd(filename):
    f = open(filename)
    r = f.read()
    f.close()
    return r


if __name__ == "__main__":
    setup(name='astrolib',
    version='1.0.0',
    description='IAG Python Boot Camp',
    author='julio',
    author_email='julio@server.com',
    license='GNU GPLv3.0',
    include_package_data=True,
    zip_safe=False,
    install_requires=['numpy'],
    #~ install_requires=['numpy >= 1.6.0'],
    #~ long_description=rd('README.md'),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        ],
    )
