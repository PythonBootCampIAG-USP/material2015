# -*- coding:utf-8 -*-

"""
IAG Pyhton Boot Camp

code profile tutorial. To be executed preferably in ``ipython`` (with --pylab).
"""
__author__ = "Daniel Moser"
__email__ = "dmfaes@gmail.com"

# The example is to create a vector and sum in many different ways to compare
#code efficiency.
import time 
import numpy as np
from itertools import product as iprod
import cProfile

def create_list_1(x):
    """ Create an incremental list using a ``for`` loop.
    
    x = length of the array
    """
    vec = []
    for i in range(x):
        vec += [i]
    return vec
        
        
def sum_list_1(vec):
    """ Sum a vector using a POSITIONAL ``for`` loop.
    
    vec = vector to be summed
    """ 
    total = 0
    for i in range(len(vec)):
        total += vec[i]
    return total
    
    
def sum_list_2(vec):
    """ Sum a vector using a SEQUENTIAL ``for`` loop.
    
    vec = vector to be summed
    """ 
    total = 0
    for vec_item in vec:
        total += vec_item
    return total
    
    
if __name__ == '__main__':
    create_funcs = [range, np.arange, create_list_1]
    sum_funcs = [np.sum, sum_list_1, sum_list_2]

    n = 5000#00
    x = 5000#00

    for cref,sumf in iprod(create_funcs, sum_funcs):
        t0 = time.time()
        for i in range(n):
            vec = cref(10)
            summed = sumf(vec)
        tf = time.time()
        print('{0:>15s}, {1:>15s}, {2:.2f} {3}'.format(cref.__name__, 
        sumf.__name__, (tf-t0), summed))
        

